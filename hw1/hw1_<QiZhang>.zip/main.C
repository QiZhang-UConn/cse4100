#include <iostream>
#include <iomanip>
#include "parser.H"

using namespace std;
int main(int argc,char* argv[]) {
   Parser p;
   p.run();
}

